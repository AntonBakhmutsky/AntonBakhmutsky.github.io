# Markup Boilerplate

**Installation**

```
npm i
```

**Start Dev Server**

```
npm run serve
```

**Build Prod Version**

```
npm run prod
```

**Build Dev Version**

```
npm run dev
```

**Run Watcher**

```
npm run watch
```
